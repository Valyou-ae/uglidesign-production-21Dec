# Mockup Product Catalog

A complete product catalog for POD (Print-on-Demand) mockup generation with **51 products** across 5 categories, including frontend-to-backend ID mappings and POD industry standard specifications.

## 📦 Products Included

| Category | Products |
|----------|----------|
| Women's Apparel | 8 (Crop top, Tank, Polo, Dress, 3/4 Sleeve, Long Sleeve, Knitwear, Jacket) |
| Men's Apparel | 11 (T-shirt, Tank, Polo, 3/4 Sleeve, Long Sleeve, Embroidered, Jacket, Knitwear, Leggings, Hoodie, Sweatshirt) |
| Kids' Apparel | 7 (T-shirt, Hoodie, Sweatshirt, Long Sleeve, Leggings, Baby Bodysuit, Hat) |
| Accessories | 12 (Tote, Drawstring, Backpack, Duffle, Phone Cases, Laptop Sleeves, Mousepad, Flip Flops, Socks, Face Mask) |
| Home & Living | 17 (Mugs, Tumbler, Water Bottle, Posters, Canvas, Blanket, Pillows, Beach Towel, Coasters, Notebook, Postcards, Stickers, Magnets) |

## 🚀 Quick Start on Replit

### 1. Create New Replit
- Go to [replit.com](https://replit.com)
- Click **+ Create Repl**
- Choose **Node.js** template
- Name it `mockup-product-catalog`

### 2. Upload Files
Upload all files maintaining this structure:
```
/
├── package.json
├── tsconfig.json
├── src/
│   ├── index.ts
│   ├── types.ts
│   ├── mappings.ts
│   ├── utils.ts
│   ├── test.ts
│   └── data/
│       ├── index.ts
│       ├── colors.ts
│       ├── sizes.ts
│       └── products.ts
```

### 3. Install Dependencies
In the Replit Shell, run:
```bash
npm install
```

### 4. Run Tests
```bash
npm run test
```

### 5. Build for Production
```bash
npm run build
```

## 📖 Usage Examples

### Import the catalog
```typescript
import { 
  PRODUCTS,
  getProduct,
  getBackendId,
  getPrintfulId,
  getPrintAreaPixels,
} from './src';
```

### Get a product
```typescript
// By product ID
const tshirt = getProduct('mens-tshirt');

// By frontend name
const hoodie = getProduct('Hoodie');

// By backend ID
const mug = getProduct('MUG_11');
```

### Get backend ID from frontend name
```typescript
const backendId = getBackendId('T-Shirt');  // 'MENS_TSHIRT'
const mugId = getBackendId('Mug (11oz)');   // 'MUG_11'
```

### Get Printful ID
```typescript
const printfulId = getPrintfulId('MENS_TSHIRT');  // '71'
```

### Get print area dimensions
```typescript
const pixels = getPrintAreaPixels('mens-tshirt');
// { width: 3600, height: 4800 }

const mugPixels = getPrintAreaPixels('mug-11oz');
// { width: 2550, height: 900 }
```

### Filter by category
```typescript
import { getProductsByCategory } from './src';

const accessories = getProductsByCategory('Accessories');
// Returns array of 12 accessory products
```

### Filter by print method
```typescript
import { getProductsByPrintMethod } from './src';

const aopProducts = getProductsByPrintMethod('aop');
// Returns all AOP products (leggings, blanket, etc.)
```

### Search products
```typescript
import { searchProducts } from './src';

const results = searchProducts('mug');
// Returns all mug products
```

## 🗂️ Data Structure

### Product Interface
```typescript
interface Product {
  id: string;              // 'mens-tshirt'
  frontendName: string;    // 'T-Shirt'
  backendId: string;       // 'MENS_TSHIRT'
  category: string;        // 'mens_apparel'
  subcategory: string;     // 'T-Shirts'
  printMethod: string;     // 'dtg' | 'sublimation' | 'aop' | 'embroidery'
  printAreas: PrintArea[];
  sizes: ProductSize[];
  colors: ProductColor[];
  printfulId: string;      // '71'
  promptKeywords: string[];
}

interface PrintArea {
  name: string;            // 'Front'
  widthInches: number;     // 12
  heightInches: number;    // 16
  widthPixels: number;     // 3600 (at 300 DPI)
  heightPixels: number;    // 4800
  position: string;        // '3-4" below collar'
}
```

## 🔗 Mapping Reference

### Frontend → Backend ID
| Frontend Name | Backend ID |
|--------------|------------|
| T-Shirt | MENS_TSHIRT |
| Hoodie | MENS_HOODIE |
| Mug (11oz) | MUG_11 |
| Mug (15oz) | MUG_15 |
| Phone Case (iPhone 14) | PHONE_IP14 |
| Blanket | BLANKET |

### Backend → Printful ID
| Backend ID | Printful ID |
|------------|-------------|
| MENS_TSHIRT | 71 |
| MENS_HOODIE | 146 |
| MUG_11 | 19 |
| MUG_15 | 534 |
| BLANKET | 339 |

## 📐 Print Area Quick Reference

| Product | Print Area | Pixels (300 DPI) |
|---------|------------|------------------|
| T-Shirt Front | 12" × 16" | 3600 × 4800 |
| Hoodie Front | 12" × 12" | 3600 × 3600 |
| Mug 11oz | 8.5" × 3" | 2550 × 900 |
| Mug 15oz | 8.5" × 3.5" | 2550 × 1050 |
| Poster 24×36 | 24" × 36" | 7200 × 10800 |
| Blanket | 50" × 60" | 7500 × 9000 |
| Phone Case | 3" × 6" | 900 × 1800 |

## 📁 File Structure

```
src/
├── index.ts          # Main exports
├── types.ts          # TypeScript interfaces
├── mappings.ts       # Frontend-to-backend mappings
├── utils.ts          # Helper functions
├── test.ts           # Test/example file
└── data/
    ├── index.ts      # Data exports
    ├── colors.ts     # Color palettes (18 palettes)
    ├── sizes.ts      # Size charts (25 size charts)
    └── products.ts   # All 51 products
```

## 🛠️ Available Functions

| Function | Description |
|----------|-------------|
| `getProduct(id)` | Get product by ID, frontend name, or backend ID |
| `getBackendId(frontendName)` | Get backend ID from frontend name |
| `getPrintfulId(backendId)` | Get Printful ID from backend ID |
| `getPrintAreaPixels(productId)` | Get print area in pixels |
| `getPrintAreaInches(productId)` | Get print area in inches |
| `getAllPrintAreas(productId)` | Get all print areas for a product |
| `getProductsByCategory(category)` | Get all products in a category |
| `getProductsByPrintMethod(method)` | Get all products by print method |
| `searchProducts(keyword)` | Search products by keyword |
| `getCatalogStats()` | Get catalog statistics |

## 📄 License

MIT
