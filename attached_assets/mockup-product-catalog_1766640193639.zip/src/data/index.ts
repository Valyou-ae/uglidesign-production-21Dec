/**
 * Data exports
 */

export { COLORS, default as colors } from './colors';
export { SIZES, default as sizes } from './sizes';
export { PRODUCTS, default as products } from './products';
export { 
  AOP_PRODUCTS, 
  getAllAOPProducts,
  getAOPProduct,
  getAOPProductsByCategory,
  getAOPPrintDimensions,
  getCriticalSeams,
  getPatternScaleRecommendation,
  AOP_SUMMARY,
  default as aopProducts 
} from './aop-specifications';
